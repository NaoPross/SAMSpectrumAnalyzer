/* 
 * File:   main.c
 * Author: _randelovicp
 *
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>

#include "mcc_generated_files/mcc.h"
#include "HT1632.h" // Ulteriori librerie vengono inserite dopo di questa.

#include "Font_5x4.h"

char str[]="Hello world!";

int t, wd;

void INT_TMR0(){        //TMR0 incrementa t ogni millisecondo (1ms)
    t++;
}

void delay(int delay){      //Funzione simile al delay() di Arduino
    while(t<=delay);        //(funzione bloccante)
    t=0;
}

void main(void) {
    
    //Inizializzazioni:
    SYSTEM_Initialize();
    TMR0_SetInterruptHandler(INT_TMR0);     //INT_TMR0 = nome del TMR0
    INTERRUPT_GlobalInterruptEnable();
    
    beginCS();      //Inizializzazione della libreria HT1632.h
    
    selectChannel(1);
    wd = getTextWidth(str, FONT_5X4_END, FONT_5X4_HEIGHT, 1);
    
    while(1){
        
        for(int x=0; x<(wd+OUT_SIZE); x++){
                
                clear();    
                drawText(str, OUT_SIZE - x, 5, FONT_5X4, FONT_5X4_END, FONT_5X4_HEIGHT, 1, 1, 31);
                render();
                delay(100);
                
            }
        
    }
    
    return;
}

