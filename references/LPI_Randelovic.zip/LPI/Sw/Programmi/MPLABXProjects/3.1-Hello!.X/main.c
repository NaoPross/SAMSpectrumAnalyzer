/* 
 * File:   main.c
 * Author: _randelovicp
 *
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>

#include "mcc_generated_files/mcc.h"
#include "HT1632.h" // Ulteriori librerie vengono inserite dopo di questa.

#include "Font_5x4.h"


char str[]="Hello!";

void main(void) {
    
    //Inizializzazioni:
    SYSTEM_Initialize();
    
    beginCS();      //Inizializzazione della libreria HT1632.h
    
    selectChannel(1);
    drawText(str, 4, 5, FONT_5X4, FONT_5X4_END, FONT_5X4_HEIGHT, 1, 0, OUT_SIZE);
    
    render();
    
    while(1){
               
    }
    
    return;
}

