/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using MPLAB(c) Code Configurator

  @Description:
    This header file provides implementations for pin APIs for all pins selected in the GUI.
    Generation Information :
        Product Revision  :  MPLAB(c) Code Configurator - 4.15
        Device            :  PIC18F45K22
        Version           :  1.01
    The generated drivers are tested against the following:
        Compiler          :  XC8 1.35
        MPLAB             :  MPLAB X 3.40

    Copyright (c) 2013 - 2015 released Microchip Technology Inc.  All rights reserved.

    Microchip licenses to you the right to use, modify, copy and distribute
    Software only when embedded on a Microchip microcontroller or digital signal
    controller that is integrated into your product or third party product
    (pursuant to the sublicense terms in the accompanying license agreement).

    You should refer to the license agreement accompanying this Software for
    additional information regarding your rights and obligations.

    SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
    EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
    MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
    IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
    CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
    OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
    INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
    CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
    SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
    (INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.

*/


#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set CS1 aliases
#define CS1_TRIS               TRISCbits.TRISC2
#define CS1_LAT                LATCbits.LATC2
#define CS1_PORT               PORTCbits.RC2
#define CS1_ANS                ANSELCbits.ANSC2
#define CS1_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define CS1_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define CS1_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define CS1_GetValue()           PORTCbits.RC2
#define CS1_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define CS1_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define CS1_SetAnalogMode()  do { ANSELCbits.ANSC2 = 1; } while(0)
#define CS1_SetDigitalMode() do { ANSELCbits.ANSC2 = 0; } while(0)

// get/set SCK aliases
#define SCK_TRIS               TRISCbits.TRISC3
#define SCK_LAT                LATCbits.LATC3
#define SCK_PORT               PORTCbits.RC3
#define SCK_ANS                ANSELCbits.ANSC3
#define SCK_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define SCK_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define SCK_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define SCK_GetValue()           PORTCbits.RC3
#define SCK_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define SCK_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define SCK_SetAnalogMode()  do { ANSELCbits.ANSC3 = 1; } while(0)
#define SCK_SetDigitalMode() do { ANSELCbits.ANSC3 = 0; } while(0)

// get/set WR aliases
#define WR_TRIS               TRISCbits.TRISC4
#define WR_LAT                LATCbits.LATC4
#define WR_PORT               PORTCbits.RC4
#define WR_ANS                ANSELCbits.ANSC4
#define WR_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define WR_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define WR_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define WR_GetValue()           PORTCbits.RC4
#define WR_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define WR_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define WR_SetAnalogMode()  do { ANSELCbits.ANSC4 = 1; } while(0)
#define WR_SetDigitalMode() do { ANSELCbits.ANSC4 = 0; } while(0)

// get/set DATA aliases
#define DATA_TRIS               TRISCbits.TRISC5
#define DATA_LAT                LATCbits.LATC5
#define DATA_PORT               PORTCbits.RC5
#define DATA_ANS                ANSELCbits.ANSC5
#define DATA_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define DATA_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define DATA_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define DATA_GetValue()           PORTCbits.RC5
#define DATA_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define DATA_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define DATA_SetAnalogMode()  do { ANSELCbits.ANSC5 = 1; } while(0)
#define DATA_SetDigitalMode() do { ANSELCbits.ANSC5 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/