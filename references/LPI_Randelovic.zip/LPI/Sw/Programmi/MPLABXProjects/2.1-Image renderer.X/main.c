/* 
 * File:   main.c
 * Author: _randelovicp
 *
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>

#include "mcc_generated_files/mcc.h"
#include "HT1632.h" // Ulteriori librerie vengono inserite dopo di questa.

#include "images.h"


void main(void) {
    
    //Inizializzazioni:
    SYSTEM_Initialize();
    
    beginCS();      //Inizializzazione della libreria HT1632.h
    
    selectChannel(1);
    drawImage(IMG_MUSIC, IMG_MUSIC_WIDTH, IMG_MUSIC_HEIGHT, 0, 0, 0, 0, OUT_SIZE);    
    render();
            
    while(1){      
        
    }
    
    return;
}

