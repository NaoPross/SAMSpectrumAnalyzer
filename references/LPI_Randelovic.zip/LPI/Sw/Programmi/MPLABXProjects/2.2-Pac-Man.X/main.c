/* 
 * File:   main.c
 * Author: _randelovicp
 *
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>

#include "mcc_generated_files/mcc.h"
#include "HT1632.h" // Ulteriori librerie vengono inserite dopo di questa.

#include "images.h"

int t;

void INT_TMR0(){        //TMR0 incrementa t ogni millisecondo (1ms)
    t++;
}

void delay(int delay){      //Funzione simile al delay() di Arduino
    while(t<=delay);        //(funzione bloccante)
    t=0;
}

void main(void) {
    
    //Inizializzazioni:
    SYSTEM_Initialize();
    TMR0_SetInterruptHandler(INT_TMR0);     //INT_TMR0 = nome del TMR0
    INTERRUPT_GlobalInterruptEnable();
    
    beginCS();      //Inizializzazione della libreria HT1632.h
    selectChannel(1);
    
    while(1){
        
        for(int x=0; x<44; x++){
            
            delay(150);
            clear();
            drawImage(IMG_PACMAN_A, IMG_PACMAN_WIDTH, IMG_PACMAN_HEIGHT, x-IMG_PACMAN_WIDTH, 1, 0, 0, OUT_SIZE);
            render();
            
            x++;
            
            delay(150);
            clear();
            drawImage(IMG_PACMAN_B, IMG_PACMAN_WIDTH, IMG_PACMAN_HEIGHT, x-IMG_PACMAN_WIDTH, 1, 0, 0, OUT_SIZE);
            render();
            
        }
        
    }
    
    return;
}

