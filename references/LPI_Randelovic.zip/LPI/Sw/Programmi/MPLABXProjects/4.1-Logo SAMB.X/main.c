/* 
 * File:   main.c
 * Author: _randelovicp
 *
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "HT1632.h"
#include "Font_5x4.h"
#include "Images.h"
#include "mcc_generated_files/mcc.h"
#include <xc.h>

#define gutterSpace 1       //Spaziatura tra i caratteri

int i, t, wd;
char disp1 [] = "Bellinzona";

void INT_TMR0(){
    t++;                    //TMR0 impostato a 1ms
}

void delay(int delay){      //funzione simile al delay() di Arduino
    while(t<=delay);
    t=0;
}

void main(void) {
    
    /* Inizializzazioni */
    
    SYSTEM_Initialize();    
    TMR0_SetInterruptHandler(INT_TMR0);    
    INTERRUPT_GlobalInterruptEnable();
       
    beginCS();    
    wd = getTextWidth(disp1, FONT_5X4_END, FONT_5X4_HEIGHT, gutterSpace);
    
    clear();            //Pulisci il buffer
    selectChannel(1);   //Seleziona il colore rosso
        
    clearPixel(10, 10, 1);
        
    setPixel(10, 10, 0);
    render();
    
    while(1){        
        
        
        //Salva l'immagine nel buffer
        drawImage(IMG_SAM, IMG_SAM_WIDTH, IMG_SAM_HEIGHT, 1, 0, 0, 0, OUT_SIZE);
        //Salva la scritta nel buffer
        drawText(disp1, 18 - i, 1, FONT_5X4, FONT_5X4_END, FONT_5X4_HEIGHT, gutterSpace, 1, 19);
        
        //Stampa sul display il contenuto del buffer
        render();
            
        if(i<=wd+18)i++;
            else i=0;
        
        delay(100);
        
    }    
}

