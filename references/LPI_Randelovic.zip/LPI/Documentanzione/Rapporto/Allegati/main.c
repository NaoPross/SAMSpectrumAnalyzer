/* 
 * File:   main.c
 * Author: _randelovicp
 *
 * Created on 11. maggio 2017, 13:56
 */

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>

#include "mcc_generated_files/mcc.h"
#include "HT1632.h" // Ulteriori librerie vengono inserite dopo di questa.

int t;

void INT_TMR0(){        //TMR0 incrementa t ogni millisecondo (1ms)
    t++;
}

void main(void) {
    
    //Inizializzazioni:
    SYSTEM_Initialize();
    TMR0_SetInterruptHandler(INT_TMR0);     //INT_TMR0 = nome del TMR0
    INTERRUPT_GlobalInterruptEnable();
    
    beginCS();      //Inizializzazione della libreria HT1632.h
    
    while(1){
        
        //Scrivere qui la parte principale del programma
        
    }
    
    return;
}

